import { useState } from 'react'
import { Badge, Card, Empty, Filters, Heading, Metrics, ReviewAction, Table } from '../ManagementPrimitives.tsx'
import { dateTime } from '../ManagementTypes.ts'
import type { ScreenProps } from '../ManagementTypes.ts'

export function RelationshipsScreen({ data, canReview }: ScreenProps) {
  const [query, setQuery] = useState(''), [status, setStatus] = useState('')
  const rows = data.relationships.filter((r) => (!status || r.status === status) && `${r.parent} ${r.student} ${r.id}`.toLocaleLowerCase('vi-VN').includes(query.toLocaleLowerCase('vi-VN')))
  return <><Heading title="Liên kết phụ huynh–học sinh" detail="Xác minh quan hệ trong cùng trung tâm" />
    <Metrics items={['ACTIVE', 'PENDING_VERIFICATION', 'INACTIVE'].map((s, i) => ({ label: ['Đang hiệu lực', 'Chờ xác minh', 'Đã thu hồi'][i], value: data.relationships.filter((r) => r.status === s).length, detail: ['Quan hệ đã xác minh', 'Chưa mở quyền xem học sinh', 'Giữ lịch sử để tra cứu'][i] }))} />
    <Filters {...{ query, setQuery, status, setStatus }} statuses={['PENDING_VERIFICATION', 'ACTIVE', 'INACTIVE']} />
    <Card title="Liên kết phụ huynh–học sinh">{rows.length ? <Table caption="Quan hệ phụ huynh học sinh" columns={['Phụ huynh', 'Học sinh', 'Bằng chứng', 'Trạng thái', 'Thao tác']} rows={rows.map((r) => ({ id: r.id, cells: [r.parent, r.student, <>{r.evidence}<small>{r.verifiedBy ? `${r.verifiedBy} · ${r.verifiedAt ? dateTime(r.verifiedAt, data.timezone) : ''}` : 'Chưa xác minh'}</small></>, <Badge key="status" value={r.status} />, <div key="actions" className="mo-actions"><details><summary>Xem căn cứ</summary><p>{r.evidence}</p><p>Mã liên kết: {r.id}</p></details>{canReview && r.status !== 'INACTIVE' && <ReviewAction label={r.status === 'PENDING_VERIFICATION' ? 'Xác minh' : 'Thu hồi'} title={`${r.status === 'PENDING_VERIFICATION' ? 'Xác minh' : 'Thu hồi'} · ${r.parent} / ${r.student}`} warning={r.status === 'PENDING_VERIFICATION' ? 'Chỉ xác minh sau khi đối chiếu chứng cứ và cùng tenant. Họ tên không đủ để cấp quyền.' : 'Phụ huynh sẽ mất quyền xem học sinh qua liên kết này.'} />}</div>] }))} /> : <Empty filtered={!!(query || status)} />}</Card>
    <Card title="Tạo liên kết mới" detail="Chọn Parent và Student thuộc cùng trung tâm trước khi xác minh.">{canReview ? <ReviewAction label="Chuẩn bị liên kết" fields={[{ name: 'parent', label: 'Phụ huynh', options: [...new Set(data.relationships.map((r) => r.parent))] }, { name: 'student', label: 'Học sinh', options: [...new Set(data.relationships.map((r) => r.student))] }, { name: 'evidenceReference', label: 'Căn cứ xác minh' }, { name: 'reason', label: 'Lý do', type: 'textarea' }]} warning="Lựa chọn mẫu cùng tenant. Chưa có API tra cứu đầy đủ; chưa lưu hoặc mở quyền cho phụ huynh." /> : <p>Bạn chỉ có quyền xem.</p>}<p>Thu hồi cần xác nhận và lưu vết; quan hệ chờ xác minh không cấp quyền xem học sinh.</p></Card>
  </>
}
